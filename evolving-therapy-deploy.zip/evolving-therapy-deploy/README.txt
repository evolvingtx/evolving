EVOLVING THERAPY & WELLNESS — DEPLOY INSTRUCTIONS
===================================================

HOW TO GO LIVE IN 5 MINUTES
------------------------------
1. Go to https://netlify.com → create a free account
2. Click "Add new site" → "Deploy manually"
3. Drag this entire folder onto the upload area
4. Done. You get a live URL instantly.
5. Rename it: Settings → Domain management → Edit site name


SET UP YOUR CONSULT FORM INBOX (5 min — do this first!)
---------------------------------------------------------
1. Go to https://formspree.io and create a free account
2. Click "New Form" → name it "OT Consult Requests"
3. Copy your endpoint: https://formspree.io/f/xabcd123
4. Open index.html in any text editor
5. Find: const FORMSPREE_URL = "https://formspree.io/f/YOUR_FORM_ID";
6. Replace YOUR_FORM_ID with your actual ID
7. Save and re-upload to Netlify
8. Test it — you should receive an email

Free plan = 50 submissions/month.


CHANGING BETA CODES
---------------------
Find in index.html: const VALID_CODES = [...];
Add/remove codes. Re-upload.


SAFETY FEATURES BUILT IN
--------------------------
- Clinical guardrails in every prompt (no rotatory input, no weighted
  equipment, no brushing protocols, no oral motor exercises, etc.)
- Disclaimer shown on every single output
- Yellow risk warnings for Sensory, Oral Motor, Attention & Regulation
- "Request OT Consult" button on every output
- Consult banner escalates for high-risk area selections


ADDING PAID ACCESS LATER
--------------------------
Come back to Claude: "add Stripe payment gate"
The code is already structured for it.
